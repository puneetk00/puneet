<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This software is designed to work with Magento community edition and
 * its use on an edition other than specified is prohibited. aheadWorks does not
 * provide extension support in case of incorrect edition use.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Shopbybrand
 * @version    1.5.0
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */


class AW_Shopbybrand_Model_Observer
{
    protected function forwardToAllBrands($request)
    {
        $request->initForward()
            ->setControllerName('index')
            ->setModuleName('shopbybrands')
            ->setActionName('allBrandsView')
            ->setDispatched(false)
        ;
        return $this;
    }

    public function afterProductSave(Varien_Event_Observer $observer)
    {
        $product = $observer->getEvent()->getDataObject();

        $newBrandId = $product->getData('aw_shopbybrand_brand');
        $oldBrandId = $product->getOrigData('aw_shopbybrand_brand');
        $productId = $product->getId();

        if (!$productId || $newBrandId == $oldBrandId) {
            return $this;
        }

        if ($oldBrandId) {
            Mage::getModel('awshopbybrand/brand')
                ->load($oldBrandId)
                ->removeProduct($productId);
        }

        if ($newBrandId) {
            Mage::getModel('awshopbybrand/brand')
                ->load($newBrandId)
                ->removeProduct($productId)
                ->addProduct($productId);
        }

        return $this;
    }


    public function preDispatch($event)
    {
        $controllerAction = $event->getControllerAction();
        $request = $controllerAction->getRequest();
        $module = $request->getModuleName();
        $action = $request->getActionName();

        if($module == 'cms' && $action == 'noRoute'){
            if (!Mage::helper('awshopbybrand')->isModuleEnabled()) {
                return $this;
            }

            $pathRoutes = explode('/', Mage::app()->getFrontController()->getRequest()->getPathInfo());
            $key = array_search(Mage::helper('awshopbybrand/config')->getAllBrandsUrlKey(), $pathRoutes);

            if ($key == 1) {
                if (!isset($pathRoutes[++$key])) {
                    $this->forwardToAllBrands($request);
                } else {

                    //Load brand and add it to registry
                    $brandUrlKey = $pathRoutes[$key];
                    if (!$brandUrlKey) {
                        return $this->forwardToAllBrands($request);
                    }

                    $websiteId = Mage::app()->getWebsite()->getId();
                    /** @var $brandsCollection AW_Shopbybrand_Model_Resource_Brand_Collection */
                    $brandsCollection = Mage::getModel('awshopbybrand/brand')->getCollection();
                    $brandsCollection
                        ->addFieldToFilter('url_key', array('eq' => $brandUrlKey))
                        ->addWebsiteFilter($websiteId)
                        ->addStatusFilter()
                    ;

                    $brand = $brandsCollection->getFirstItem();

                    if (null === $brand->getId()) {
                        return $this;
                    }

                    $request->initForward()
                        ->setControllerName('index')
                        ->setModuleName('shopbybrands')
                        ->setActionName('brandPageView')
                        ->setPost('brand_id', $brand->getId())
                        ->setDispatched(false)
                    ;
                }
            }
        }
        return $this;
    }

    public function afterPrepareLayout($event)
    {
        $block = $event->getBlock();
        if (!$block instanceof Mage_Adminhtml_Block_Catalog_Product_Edit_Tabs) {
            return;
        }

        if (!Mage::getSingleton('admin/session')->isAllowed('catalog/awshopbybrand/sbb_product_tab')) {
            if ($setId = $block->getProduct()->getAttributeSetId()) {
                $groupCollection = Mage::getResourceModel('eav/entity_attribute_group_collection')
                    ->setAttributeSetFilter($setId)
                    ->setSortOrder()
                    ->load();

                $tabs = $block->getTabsIds();

                foreach ($groupCollection as $group){
                    $tabName = 'group_'.$group->getId();
                    if($group->getAttributeGroupName() == 'Product Brand' && in_array($tabName, $tabs)){
                        $removeTabName = $tabName;
                        break;
                    }
                }

                if($removeTabName){
                    $block->removeTab($removeTabName);

                    // fix tab selection, as we might have removed the active tab
                    if (count($tabs) == 0) {
                        $block->setActiveTab(null);
                    } else {
                        $block->setActiveTab($tabs[0]);
                    }
                }
            }
        }
    }

    public function afterProductDelete(Varien_Event_Observer $observer)
    {
        $product = $observer->getEvent()->getProduct();
        $brandCollection = Mage::getModel('awshopbybrand/brand')->getCollection();
        $brandCollection->getSelect()->where('FIND_IN_SET(?, products)', $product->getId());
        foreach ($brandCollection as $brand) {
            $brand->removeProduct($product->getId())->save();
        }
        return $this;
    }
}