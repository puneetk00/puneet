<?php
class Si_Discountdivali_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 