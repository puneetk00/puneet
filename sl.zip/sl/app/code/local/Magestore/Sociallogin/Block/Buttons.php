<?php
class Magestore_Sociallogin_Block_Buttons extends Magestore_Sociallogin_Block_Sociallogin
{
	 
}