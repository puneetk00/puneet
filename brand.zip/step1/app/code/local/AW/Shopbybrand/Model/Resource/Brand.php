<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This software is designed to work with Magento community edition and
 * its use on an edition other than specified is prohibited. aheadWorks does not
 * provide extension support in case of incorrect edition use.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Shopbybrand
 * @version    1.5.0
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */


class AW_Shopbybrand_Model_Resource_Brand extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {
        $this->_init('awshopbybrand/brand', 'id');
    }

    protected function _beforeSave(Mage_Core_Model_Abstract $object)
    {
        if (!$this->getIsUniqueUrlKey($object)) {
            Mage::throwException(Mage::helper('awshopbybrand')->__('Brand with the same url_key already exists.'));
        }

        if (is_array($object->getData('website_ids'))) {
            $object->setData('website_ids', implode(',', $object->getData('website_ids')));
        }
        return parent::_beforeSave($object);
    }

    public function getIsUniqueUrlKey($object)
    {
        $select = $this->_getReadAdapter()->select()
            ->from(array('brand' => $this->getMainTable()))
            ->where('brand.url_key = ?', $object->getData('url_key'));

        if ($object->getId()) {
            $select->where('brand.id <> ?', $object->getId());
        }

        if ($this->_getReadAdapter()->fetchRow($select)) {
            return false;
        }

        return true;
    }

    protected function _afterDelete(Mage_Core_Model_Abstract $object)
    {
        // DB cleanup after brand deletion
        $write = $this->_getWriteAdapter();
        $write->query(
            "DELETE FROM {$this->getTable('awshopbybrand/brand_store')} "
            . "WHERE brand_id = {$object->getId()}"
        );
        return parent::_afterDelete($object);
    }
}