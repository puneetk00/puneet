<?php

namespace Infortis\UltraMegamenu\Observer;

abstract class AbstractObserver
{
}