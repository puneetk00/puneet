<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This software is designed to work with Magento community edition and
 * its use on an edition other than specified is prohibited. aheadWorks does not
 * provide extension support in case of incorrect edition use.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Shopbybrand
 * @version    1.5.0
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */


class AW_Shopbybrand_Block_Adminhtml_Brand_Edit_Tab_Brandpage
    extends Mage_Adminhtml_Block_Widget_Form
    implements Mage_Adminhtml_Block_Widget_Tab_Interface
{
    protected $_store = null;

    public function getStore()
    {
        if ($this->_store == null) {
            $storeId = (int)$this->getRequest()->getParam('store', 0);
            $this->_store = Mage::app()->getStore($storeId);
        }
        return $this->_store;
    }

    public function getTabLabel()
    {
        return $this->__('Brand Page');
    }

    public function getTabTitle()
    {
        return $this->__('Brand Page');
    }

    public function canShowTab()
    {
        return true;
    }

    public function isHidden()
    {
        return false;
    }

    protected function _prepareForm()
    {
        $form = new Varien_Data_Form();
        $storeId = $this->getStore()->getId();

        if (Mage::getSingleton('cms/wysiwyg_config')->isEnabled()) {
            $this->getLayout()->getBlock('head')->setCanLoadTinyMce(true);
        }
        $this->setForm($form);

        $_fieldset = $form->addFieldset(
            'brandpage_form',
            array(
                'legend' => $this->__('Brand Page')
            )
        );

        $_data = Mage::registry('current_brand');

        $storeValues = $_data->getData('store_values');
        if ($storeId && isset($storeValues[$storeId])) {
            $currentStoreValues = $storeValues[$storeId];
        } else {
            $currentStoreValues = array();
        }

        $defaultPageTitle = !array_key_exists('page_title', $currentStoreValues);
        if (!$defaultPageTitle) {
            $_data->setData('page_title', $currentStoreValues['page_title']);
        }
        $_fieldset->addField(
            'page_title',
            'text',
            array(
                'name'                  => 'page_title',
                'label'                 => $this->__('Page Title'),
                'title'                 => $this->__('Page Title'),
                'disabled'              => $storeId && $defaultPageTitle ? true : false,
                'after_element_html'    => '<td class="scope-label"><span class="nobr">' . Mage::helper('adminhtml')->__('[STORE VIEW]') . '</span></td>'
                                            . ($storeId ? '<td class="value use-default">
                                            <input id="page_title_default" type="checkbox" ' . ($defaultPageTitle ? 'checked=""':'') . ' value="page_title" onclick="toggleValueElements(this, this.parentNode.parentNode)" name="use_default[]">
                                            <label class="normal" for="page_title_default">' . Mage::helper('adminhtml')->__('Use Default Value') . '</label>
                                            </td>' : ''),
            )
        );

        $_fieldset->addField(
            'url_key',
            'text',
            array(
                'name'     => 'url_key',
                'label'    => $this->__('URL key'),
                'title'    => $this->__('URL key'),
                'required' => true,
                'class'    => 'validate-identifier',
                'after_element_html'    => '<td class="scope-label"><span class="nobr">' . Mage::helper('adminhtml')->__('[GLOBAL]') . '</span></td>',
            )
        );
        $inputType = 'textarea';
        if (Mage::getSingleton('cms/wysiwyg_config')->isEnabled()) {
            $inputType = 'editor';
        }

        $defaultDescription = !array_key_exists('description', $currentStoreValues);
        if (!$defaultDescription) {
            $_data->setData('description', $currentStoreValues['description']);
        }
        $wysiwygConfig = Mage::getSingleton('awshopbybrand/source_wysiwyg')->getConfig(
            array('add_variables' => false)
        );
        $_fieldset->addField(
            'description',
            $inputType,
            array(
                'name'                  => 'description',
                'label'                 => $this->__('Brand description'),
                'title'                 => $this->__('Brand description'),
                'config'                => $wysiwygConfig,
                'wysiwyg'               => true,
                'disabled'              => $storeId && $defaultDescription ? true : false,
                'after_element_html'    => '<td class="scope-label"><span class="nobr">' . Mage::helper('adminhtml')->__('[STORE VIEW]') . '</span></td>'
                                            . ($storeId ? '<td class="value use-default">
                                            <input id="description_default" type="checkbox" ' . ($defaultDescription ? 'checked=""':'') . ' value="description" onclick="toggleValueElements(this, this.parentNode.parentNode)" name="use_default[]">
                                            <label class="normal" for="description_default">' . Mage::helper('adminhtml')->__('Use Default Value') . '</label>
                                            </td>' : ''),
            )
        );

        $defaultMetaKeywords = !array_key_exists('meta_keywords', $currentStoreValues);
        if (!$defaultMetaKeywords) {
            $_data->setData('meta_keywords', $currentStoreValues['meta_keywords']);
        }
        $_fieldset->addField(
            'meta_keywords',
            'textarea',
            array(
                'name'                  => 'meta_keywords',
                'label'                 => $this->__('Meta keywords'),
                'title'                 => $this->__('Meta keywords'),
                'disabled'              => $storeId && $defaultMetaKeywords ? true : false,
                'after_element_html'    => '<td class="scope-label"><span class="nobr">' . Mage::helper('adminhtml')->__('[STORE VIEW]') . '</span></td>'
                                            . ($storeId ? '<td class="value use-default">
                                            <input id="meta_keywords_default" type="checkbox" ' . ($defaultMetaKeywords ? 'checked=""':'') . ' value="meta_keywords" onclick="toggleValueElements(this, this.parentNode.parentNode)" name="use_default[]">
                                            <label class="normal" for="meta_keywords_default">' . Mage::helper('adminhtml')->__('Use Default Value') . '</label>
                                            </td>' : ''),
            )
        );

        $defaultMetaDescription = !array_key_exists('meta_description', $currentStoreValues);
        if (!$defaultMetaDescription) {
            $_data->setData('meta_description', $currentStoreValues['meta_description']);
        }
        $_fieldset->addField(
            'meta_description',
            'textarea',
            array(
                'name'                  => 'meta_description',
                'label'                 => $this->__('Meta description'),
                'title'                 => $this->__('Meta description'),
                'disabled'              => $storeId && $defaultMetaDescription ? true : false,
                'after_element_html'    => '<td class="scope-label"><span class="nobr">' . Mage::helper('adminhtml')->__('[STORE VIEW]') . '</span></td>'
                                            . ($storeId ? '<td class="value use-default">
                                            <input id="meta_description_default" type="checkbox" ' . ($defaultMetaDescription ? 'checked=""':'') . ' value="meta_description" onclick="toggleValueElements(this, this.parentNode.parentNode)" name="use_default[]">
                                            <label class="normal" for="meta_description_default">' . Mage::helper('adminhtml')->__('Use Default Value') . '</label>
                                            </td>' : ''),
            )
        );

        $form->setValues($_data->getData());
        return parent::_prepareForm();
    }
}