<?php
class Si_Discountdivali_Model_Observer
{

			public function collectTotals(Varien_Event_Observer $observer)
			{
				
				// change category
				$category = 404;
				//Mage::log('discount 1',null,"dicount.log");
				
							$quote= $observer->getEvent()->getQuote();
							$quoteid = $quote->getId();
							//check condition here if need to apply Discount
							
							foreach($quote->getAllItems() as $_pr){
								
								if(in_array($category, $_pr->getProduct()->getCategoryIds())){ 
									$_dicount[] = $_pr->getPrice() * $_pr->getQty();
								}
								
								
							}
							
							//$discountAmount = 200;
							
							$_catdiscountsubtotal = array_sum($_dicount);
							//Mage::log(array('sum',$_catdiscountsubtotal),null,"dicount.log");
							if( $_catdiscountsubtotal >= 1000 && $_catdiscountsubtotal <= 4000 ){
								// calculate discount 10%
								$discountAmount = (($_catdiscountsubtotal * 10) / 100);
								$discountcomment = "10%";
								//Mage::log(array('discount 10%',$discountAmount),null,"dicount.log");
							}elseif( $_catdiscountsubtotal >= 4001 && $_catdiscountsubtotal <= 12000 ){
								// calculate discount 20 %
								$discountAmount = (($_catdiscountsubtotal * 20) / 100);
								$discountcomment = "20%";
								//Mage::log(array('discount 20%',$discountAmount),null,"dicount.log");
							}elseif($_catdiscountsubtotal >= 12001 && $_catdiscountsubtotal <= 15000 ){
								// calculate discount 30 %
								$discountcomment = "30%";
								$discountAmount = (($_catdiscountsubtotal * 30) / 100);
								//Mage::log(array('discount 30%',$discountAmount),null,"dicount.log");
							}
							
							
		
							if($quoteid) {
							
							if($discountAmount > 0) {
							
									$total=$quote->getBaseSubtotal();
									$quote->setSubtotal(0);
									$quote->setBaseSubtotal(0);

									$quote->setSubtotalWithDiscount(0);
									$quote->setBaseSubtotalWithDiscount(0);

									$quote->setGrandTotal(0);
									$quote->setBaseGrandTotal(0);


									$canAddItems = $quote->isVirtual()? ('billing') : ('shipping'); 
									foreach ($quote->getAllAddresses() as $address) {

										$address->setSubtotal(0);
										$address->setBaseSubtotal(0);

										$address->setGrandTotal(0);
										$address->setBaseGrandTotal(0);

										$address->collectTotals();

										$quote->setSubtotal((float) $quote->getSubtotal() + $address->getSubtotal());
										$quote->setBaseSubtotal((float) $quote->getBaseSubtotal() + $address->getBaseSubtotal());

										$quote->setSubtotalWithDiscount(
										(float) $quote->getSubtotalWithDiscount() + $address->getSubtotalWithDiscount()
										);
										$quote->setBaseSubtotalWithDiscount(
										(float) $quote->getBaseSubtotalWithDiscount() + $address->getBaseSubtotalWithDiscount()
										);

										$quote->setGrandTotal((float) $quote->getGrandTotal() + $address->getGrandTotal());
										$quote->setBaseGrandTotal((float) $quote->getBaseGrandTotal() + $address->getBaseGrandTotal());

										$quote ->save(); 

										
										
										$quote->setGrandTotal($quote->getBaseSubtotal()-$discountAmount)
										->setBaseGrandTotal($quote->getBaseSubtotal()-$discountAmount)
										->setSubtotalWithDiscount($quote->getBaseSubtotal()-$discountAmount)
										->setBaseSubtotalWithDiscount($quote->getBaseSubtotal()-$discountAmount)
										->save(); 


										if($address->getAddressType()==$canAddItems) {

										$address->setSubtotalWithDiscount((float) $address->getSubtotalWithDiscount()-$discountAmount);
										$address->setGrandTotal((float) $address->getGrandTotal()-$discountAmount);
										$address->setBaseSubtotalWithDiscount((float) $address->getBaseSubtotalWithDiscount()-$discountAmount);
										$address->setBaseGrandTotal((float) $address->getBaseGrandTotal()-$discountAmount);
										if($address->getDiscountDescription()){
										$address->setDiscountAmount(-($address->getDiscountAmount()-$discountAmount));
										$address->setDiscountDescription($address->getDiscountDescription().", Diwali $discountcomment");
										$address->setBaseDiscountAmount(-($address->getBaseDiscountAmount()-$discountAmount));
										}else {
										$address->setDiscountAmount(-($discountAmount));
										$address->setDiscountDescription("Diwali $discountcomment");
										$address->setBaseDiscountAmount(-($discountAmount));
										}
										$address->save();
										}//end: if
									} //end: foreach
									//echo $quote->getGrandTotal();

									foreach($quote->getAllItems() as $item){
									//We apply discount amount based on the ratio between the GrandTotal and the RowTotal
									$rat=$item->getPriceInclTax()/$total;
									$ratdisc=$discountAmount*$rat;
									$item->setDiscountAmount(($item->getDiscountAmount()+$ratdisc) * $item->getQty());
									$item->setBaseDiscountAmount(($item->getBaseDiscountAmount()+$ratdisc) * $item->getQty())->save();

									}


							}

							}
				//Mage::log('discount 2',null,"dicount.log");
				
			}
			
			
		
}
