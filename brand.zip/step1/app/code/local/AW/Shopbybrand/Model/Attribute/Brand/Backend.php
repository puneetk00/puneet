<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This software is designed to work with Magento community edition and
 * its use on an edition other than specified is prohibited. aheadWorks does not
 * provide extension support in case of incorrect edition use.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Shopbybrand
 * @version    1.5.0
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */


class AW_Shopbybrand_Model_Attribute_Brand_Backend extends Mage_Eav_Model_Entity_Attribute_Backend_Abstract
{
    public function afterSave($object)
    {
        parent::afterSave($object);

        $oldBrandId = $object->getOrigData($this->getAttribute()->getAttributeCode());
        $newBrandId = $object->getData($this->getAttribute()->getAttributeCode());

        if ($oldBrandId == $newBrandId) {
            return $this;
        }

        if ($oldBrandId) {
            Mage::getModel('awshopbybrand/brand')
                ->load($oldBrandId)
                ->removeProduct($object->getId());
        }

        if ($newBrandId) {
            Mage::getModel('awshopbybrand/brand')
                ->load($newBrandId)
                ->removeProduct($object->getId()) //avoid duplicates
                ->addProduct($object->getId());
        }

    }

}