<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This software is designed to work with Magento community edition and
 * its use on an edition other than specified is prohibited. aheadWorks does not
 * provide extension support in case of incorrect edition use.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Shopbybrand
 * @version    1.5.0
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */


class AW_Shopbybrand_Model_Generate
{
    /**
     * Remove all products from the brand
     */
    protected function _removeProducts($brand) {
        //remove all products from brand
        Mage::getResourceModel('awshopbybrand/brand_product_collection')->addBrandFilter($brand->getId())->removeAll();
        $brand->setProducts('')->save();
    }

    /**
     * Creates a new brand instance
     */
    protected function _createBrandIfNotExist($attribute, $option) {
        $brand = Mage::getModel('awshopbybrand/brand');
        $brandTitle = $option['label'];

        //brand exist from name
        $collection = $brand->getCollection()->addFieldToFilter('title', $brandTitle);
        if ($collection->getSize() > 0) {
            $selectedBrand = $collection->getFirstItem();

            $this->_removeProducts($selectedBrand);
            Mage::log('Brand '.$brandTitle.' is exist. All products removed from brand', '1', 'aw_shopbybrand_generated.log');

            return $selectedBrand;
        }

        try{
            $brand->setTitle($brandTitle)
                ->setPageTitle($brandTitle)
                ->setStoreIds('0')
                ->setBrandStatus(0)
                ->setUrlKey($attribute->getName().'-'.$option['value'])
                ->save();

            $allStores = Mage::app()->getStores();
            foreach ($allStores as $store) {
                $storeBrandTitle = Mage::getModel('catalog/product')->getResource()->getAttribute($attribute->getAttributeCode())
                                    ->setStoreId($store->getId())->getSource()->getOptionText($option['value']);
                if ($brandTitle != $storeBrandTitle) {
                    $brandStore = Mage::getModel('awshopbybrand/brand_store');
                    $brandStore
                        ->setBrandId($brand->getId())
                        ->setStoreId($store->getId())
                        ->setTitle($storeBrandTitle)
                        ->setPageTitle($storeBrandTitle)
                        ->setDecription(null)
                        ->setMetaDescription(null)
                        ->setMetaKeywords(null)
                        ->save()
                    ;
                }
            }

            Mage::log('Created new Brand - '.$brandTitle, '1', 'aw_shopbybrand_generated.log');
        } catch (Exception $e) {
            return null;
        }
        $newBrand = Mage::getModel('awshopbybrand/brand')->load($brand->getId());

        return $newBrand;
    }

    /**
     * Assign products to brand
     */
    protected function _assignProductsToBrandByAttr($allProductFromOption, $brand) {
        $productIds = array();
        foreach ($allProductFromOption as $product) {
            $brand->addProduct($product->getId());
            $productIds[] = $product->getId();
        }

        $brand->setProducts(implode(',', $productIds));
        $brand->save();

        Mage::log('Set '.count($productIds).' product(\'s) to Brand '.$brand->getTitle(), '1', 'aw_shopbybrand_generated.log');
    }

    public function run($attributeId){
        $helper = Mage::helper('awshopbybrand');
        Mage::log('start generated brands from attribute', '1', 'aw_shopbybrand_generated.log');

        $generatedNewBrands = 0;
        $result = array(
            'result'  => false,
        );

        if (is_null($attributeId) || empty($attributeId)) {
            $result['result'] = false;
            $result['message'] = $helper->__('Incorrect Attribute ID');
            Mage::log('Incorrect Attribute ID', '1', 'aw_shopbybrand_generated.log');
            return $result;
        }

        $attribute = Mage::getModel('catalog/product')
            ->getResource()
            ->getAttribute($attributeId);


        if(!$attribute){
            $result['result'] = false;
            $result['message'] = $helper->__("Attribute with ID '%s' not found", $attributeId);
            Mage::log('Attribute with ID '.$attributeId.' not found', '1', 'aw_shopbybrand_generated.log');
            return $result;
        }

        $attributeCode = $attribute->getAttributeCode();

        if($attribute->usesSource()){
            $allAttributeOptions = Mage::getModel('catalog/product')->getResource()->getAttribute($attributeCode)->getSource()->getAllOptions();

            if(count($allAttributeOptions) == 0){
                $result['result'] = false;
                $result['message'] = $helper->__('An attribute does not have options');
                Mage::log('An attribute does not have options', '1', 'aw_shopbybrand_generated.log');
                return $result;
            }

            foreach ($allAttributeOptions as $option) {
                if ((!is_null($option['value']) && !empty($option['value'])) &&
                    (!is_null($option['label']) && !empty($option['label']))) {
                    $allProductFromOption = Mage::getModel('catalog/product')
                        ->getCollection()
                        ->addAttributeToFilter($attributeCode, $option['value'])
                        ->addAttributeToFilter('type_id', array('in', explode(',',AW_Shopbybrand_Model_Source_Attribute::PRODUCT_TYPES)))
                        ->getItems();

                    if(count($allProductFromOption) > 0){
                        $brand = $this->_createBrandIfNotExist($attribute, $option);
                        if (!is_null($brand)) {
                            $this->_assignProductsToBrandByAttr($allProductFromOption, $brand);
                            $generatedNewBrands++;
                        }
                    }else{
                        Mage::log('Products with the option '.$option['label'].' not found', '1', 'aw_shopbybrand_generated.log');
                    }
                }
            }

        }

        if ($generatedNewBrands) {
            $result['result'] = true;
            $result['message'] = $generatedNewBrands.$helper->__(" Brand('s) has been generated successfully");
            Mage::log($generatedNewBrands.' Brand(\'s) has been generated successfully!', '1', 'aw_shopbybrand_generated.log');
        }
        else {
            $result['result'] = false;
            $result['message'] = $helper->__('Brands were not generated');
            Mage::log('Brands were not generated!', '1', 'aw_shopbybrand_generated.log');
        }

        Mage::log('end generated brands from attribute', '1', 'aw_shopbybrand_generated.log');
        return $result;
    }
}