<?php
namespace Infortis\Ultimo\Block;
use Magento\Framework\View\Element\Template;
class Test extends Template
{
}