<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This software is designed to work with Magento community edition and
 * its use on an edition other than specified is prohibited. aheadWorks does not
 * provide extension support in case of incorrect edition use.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Shopbybrand
 * @version    1.5.0
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */


class AW_Shopbybrand_Helper_Data extends Mage_Core_Helper_Abstract
{
    const RESIZED_IMAGES_FOLDER = 'resized';

    public function resizeImg($fileName, $width = null, $height = null)
    {
        if ($width === null && $height === null) {
            $height = AW_Shopbybrand_Model_Brand::IMAGE_HEIGHT;
        }
        if ($width === null) {
            $width = AW_Shopbybrand_Model_Brand::IMAGE_WIDTH;
        }

        $resizedImageFolder = self::RESIZED_IMAGES_FOLDER . DS . $width . "_" . $height;
        $baseMediaDir = Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA);
        $originalFile = $baseMediaDir . DS . $fileName;
        $baseImagePath = $this->_getFilePath($fileName);

        if($baseImagePath && '' == $fileName){
            $info = pathinfo($baseImagePath);
            $fileName = 'placeholder'. DS . $info['basename'];
        }

        $resizedImagePath = $baseMediaDir . DS . $resizedImageFolder . DS . $fileName;
        if (
            (!file_exists($resizedImagePath) && $baseImagePath)
            || (file_exists($originalFile) && filemtime($originalFile) > filemtime($resizedImagePath))
        ) {
            $imageProcessor = new Varien_Image($baseImagePath);
            $imageProcessor->constrainOnly(false);
            $imageProcessor->keepAspectRatio(true);
            $imageProcessor->keepFrame(true);
            $imageProcessor->keepTransparency(true);
            $imageProcessor->backgroundColor(array(255, 255, 255));
            $imageProcessor->quality(90);
            $imageProcessor->resize($width, $height);
            $imageProcessor->save($resizedImagePath);
        }

        return Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA) . $resizedImageFolder . DS . $fileName;
    }

    protected function _getFilePath($fileName)
    {
        $baseDirPath = Mage::getSingleton('catalog/product_media_config')->getBaseMediaPath();

        if (($fileName) && (0 !== strpos($fileName, DS , 0))) {
            $fileName = DS . $fileName;
        }
        if ('' == $fileName) {
            $fileName = null;
        }
        if ($fileName) {
            $baseDirPath = Mage::getBaseDir(Mage_Core_Model_Store::URL_TYPE_MEDIA);
            if ((!file_exists($baseDirPath . $fileName))) {
                $fileName = null;
            }
        }
        if (!$fileName) {
            $configPlaceholderImg = Mage::getStoreConfig("catalog/placeholder/image_placeholder");
            $configPlaceholderPath   = '/placeholder/' . $configPlaceholderImg;
            if ($configPlaceholderImg && file_exists($baseDirPath . $configPlaceholderPath)) {
                $fileName = $configPlaceholderPath;
            }
            else {
                $skinDir = Mage::getDesign()->getSkinBaseDir();
                $store = Mage::app()->getStore();
                if ($store->isAdmin()) {
                    $fileName = AW_Shopbybrand_Model_Brand::DEFAULT_ADMIN_IMAGE_PATH;
                } else {
                    $fileName = AW_Shopbybrand_Model_Brand::DEFAULT_IMAGE_PATH;
                }
                if (file_exists($skinDir . $fileName)) {
                    $baseDirPath = $skinDir;
                }
                else {
                    $baseDirPath = Mage::getDesign()->getSkinBaseDir(array('_theme' => 'default'));
                    if (!file_exists($baseDirPath . $fileName)) {
                        $baseDirPath = Mage::getDesign()->getSkinBaseDir(array('_theme' => 'default', '_package' => 'base'));
                    }
                }
            }
        }
        $resultFilePath = $baseDirPath . $fileName;
        if ((!$fileName) || (!file_exists($resultFilePath))) {
            throw new Exception(Mage::helper('awshopbybrand')->__('The image is not found on the path %s', $resultFilePath));
        }

        return $resultFilePath;
    }

    public function getAutogenerateAttributesCollection() {
        $catalogProductTypeId = Mage::getModel('eav/entity_type')->loadByCode(Mage_Catalog_Model_Product::ENTITY)->getEntityTypeId();

        return Mage::getModel('catalog/entity_attribute')->getCollection()
            ->setOrder('frontend_label', Varien_Data_Collection::SORT_ORDER_ASC)
            ->addFieldToFilter('entity_type_id', $catalogProductTypeId)
            ->addFieldToFilter('frontend_input', 'select')
            ->addFieldToFilter('frontend_label', array('neq' => ''))
            ->addFieldToFilter('attribute_code', array('neq' => 'aw_shopbybrand_brand'))
        ;
    }
}