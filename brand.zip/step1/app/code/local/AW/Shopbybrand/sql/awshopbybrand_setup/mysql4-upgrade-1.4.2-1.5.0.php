<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This software is designed to work with Magento community edition and
 * its use on an edition other than specified is prohibited. aheadWorks does not
 * provide extension support in case of incorrect edition use.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Shopbybrand
 * @version    1.5.0
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */

$this->startSetup();
try {
    $this->run("
        ALTER TABLE `{$this->getTable('awshopbybrand/brand')}`
            ADD COLUMN `website_ids` varchar(255) NOT NULL DEFAULT '0' after `page_title`;
        CREATE TABLE IF NOT EXISTS `{$this->getTable('awshopbybrand/brand_store')}` (
            `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
            `brand_id` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Brand ID',
            `store_id` smallint(5) unsigned NOT NULL COMMENT 'Store ID',
            `title` varchar(255),
            `page_title` varchar(255),
            `description` text,
            `meta_description` text,
            `meta_keywords` tinytext,
            PRIMARY KEY (`id`),
            KEY `brand_store_brand_id` (`brand_id`),
            KEY `brand_store_store_id` (`store_id`),
            CONSTRAINT `FK_brand_store_link_to_brand` FOREIGN KEY (`brand_id`)
                REFERENCES {$this->getTable('awshopbybrand/brand')} (`id`)
                ON DELETE CASCADE ON UPDATE CASCADE,
            CONSTRAINT `FK_brand_store_link_to_store` FOREIGN KEY (`store_id`)
               REFERENCES {$this->getTable('core/store')} (`store_id`)
               ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
    ");
} catch (Exception $ex) {
    Mage::logException($ex);
}
$this->endSetup();