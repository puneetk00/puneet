-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 28, 2016 at 05:33 PM
-- Server version: 5.5.52
-- PHP Version: 5.6.26

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_forevernewdev7738`
--

-- --------------------------------------------------------

--
-- Table structure for table `search_refine`
--

CREATE TABLE IF NOT EXISTS `search_refine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `search_refine`
--

INSERT INTO `search_refine` (`id`, `name`, `brand`) VALUES
(1, 'web developer puneet', 'puneet kumar'),
(2, 'web puneet kumar developer', 'puneet'),
(3, 'web kumar', 'sonu developer'),
(4, 'sonu ', 'kumar'),
(5, '', ''),
(6, 'web sony', 'web kumar'),
(7, 'developer dheeraj', 'developer kumar'),
(8, 'binnu', 'kumar');
