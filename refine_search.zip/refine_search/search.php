<form action="" method="get">
	<input type="text" name="q" value="<?php echo $_GET['q'] ?>">
	<input type="submit" name="submit" value="Search">
</form>

<?php
// change conection user namd pass
$con = mysql_connect('localhost','ahaan','ZIWNOU2TgnT') or die(mysql_error());
// change database name
$database = mysql_select_db("db_forevernewdev7738") or die("db not connected");

if(isset($_GET['q'])){
$queries = explode(' ',$_GET['q']);

$q = '';
foreach($queries as $query){
	$n[] = "name like '%$query%'";	
}

foreach($queries as $query){
	$b[] = "brand like '%$query%'";	
}


$q[] = implode(" and ", $n);
$q[] = implode(" and ", $b);
$q = implode(" or ", $q);



$h = "SELECT * FROM `search_refine` where $q";

// query create like this
print_r($h);

//query run search from database
$result = mysql_query($h);


// fetching result
echo "<pre>";
while($row = mysql_fetch_assoc($result))
{
	print_r($row);
}
echo "running";
mysql_close($con);
}