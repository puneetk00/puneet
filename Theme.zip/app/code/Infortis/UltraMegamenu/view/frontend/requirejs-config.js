var config = {
    paths: {
        'ultramegamenu': 'Infortis_UltraMegamenu/js/ultramegamenu'
    },
    shim: {
        'ultramegamenu': {
            deps: ['jquery', 'jquery/ui', 'enquire', 'uaccordion']
        }
    }
};
