<?php

namespace Infortis\Base\Controller\Index;

abstract class AbstractIndex extends \Magento\Framework\App\Action\Action
{
}
