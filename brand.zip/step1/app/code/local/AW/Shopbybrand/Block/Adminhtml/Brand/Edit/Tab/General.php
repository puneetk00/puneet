<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This software is designed to work with Magento community edition and
 * its use on an edition other than specified is prohibited. aheadWorks does not
 * provide extension support in case of incorrect edition use.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Shopbybrand
 * @version    1.5.0
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */


class AW_Shopbybrand_Block_Adminhtml_Brand_Edit_Tab_General
    extends Mage_Adminhtml_Block_Widget_Form
    implements Mage_Adminhtml_Block_Widget_Tab_Interface
{
    protected $_store = null;

    public function getStore()
    {
        if ($this->_store == null) {
            $storeId = (int)$this->getRequest()->getParam('store', 0);
            $this->_store = Mage::app()->getStore($storeId);
        }
        return $this->_store;
    }

    public function getTabLabel()
    {
        return $this->__('General');
    }

    public function getTabTitle()
    {
        return $this->__('General');
    }

    public function canShowTab()
    {
        return true;
    }

    public function isHidden()
    {
        return false;
    }

    protected function _prepareForm()
    {
        $form = new Varien_Data_Form();
        $this->setForm($form);

        $storeId = $this->getStore()->getId();

        $_fieldset = $form->addFieldset(
            'brand_form',
            array(
                'legend' => $this->__('General'),
            )
        );

        $_data = Mage::registry('current_brand');

        $storeValues = $_data->getData('store_values');
        if ($storeId && isset($storeValues[$storeId])) {
            $currentStoreValues = $storeValues[$storeId];
        } else {
            $currentStoreValues = array();
        }

        $defaultTitle = !array_key_exists('title', $currentStoreValues);
        if (!$defaultTitle) {
            $_data->setData('title', $currentStoreValues['title']);
        }
        $_fieldset->addField(
            'title',
            'text',
            array(
                'name'                  => 'title',
                'label'                 => $this->__('Title'),
                'title'                 => $this->__('Title'),
                'required'              => true,
                'disabled'              => $storeId && $defaultTitle ? true : false,
                'after_element_html'    => '<td class="scope-label"><span class="nobr">' . Mage::helper('adminhtml')->__('[STORE VIEW]') . '</span></td>'
                                            . ($storeId ? '<td class="value use-default">
                                            <input id="title_default" type="checkbox" ' . ($defaultTitle ? 'checked=""':'') . ' value="title" onclick="toggleValueElements(this, this.parentNode.parentNode)" name="use_default[]">
                                            <label class="normal" for="title_default">' . Mage::helper('adminhtml')->__('Use Default Value') . '</label>
                                            </td>' : ''),
            )
        );

        $_fieldset->addField(
            'brand_status',
            'select',
            array(
                'name'   => 'brand_status',
                'label'  => $this->__('Status'),
                'title'  => $this->__('Status'),
                'values' => Mage::getModel('awshopbybrand/source_status')->toOptionArray(),
                'after_element_html'    => '<td class="scope-label"><span class="nobr">' . Mage::helper('adminhtml')->__('[GLOBAL]') . '</span></td>',
            )
        );

        if (!Mage::app()->isSingleStoreMode()) {
            if ($_data->getData('website_ids') == 0) {
                $_data->setData('website_ids', $this->_getAllWebsiteIds());
            }
            $_fieldset->addField(
                'website_ids',
                'multiselect',
                array(
                    'name'     => 'website_ids[]',
                    'label'    => $this->__('Websites'),
                    'title'    => $this->__('Websites'),
                    'required' => true,
                    'values'   => Mage::getSingleton('adminhtml/system_config_source_website')->toOptionArray(),
                    'after_element_html'    => '<td class="scope-label"><span class="nobr">' . Mage::helper('adminhtml')->__('[GLOBAL]') . '</span></td>',
                )
            );
        } else {
            $_fieldset->addField(
                'website_ids',
                'hidden',
                array(
                    'name'  => 'website_ids[]',
                    'value' => Mage::app()->getStore(true)->getWebsiteId()
                )
            );
            $_data->setWebsiteIds(Mage::app()->getStore(true)->getWebsiteId());
        }

        $_fieldset->addField(
            'is_show_in_sidebar',
            'select',
            array(
                'name'   => 'is_show_in_sidebar',
                'label'  => $this->__('Show in Sidebar'),
                'title'  => $this->__('Show in Sidebar'),
                'values' => Mage::getModel('awshopbybrand/source_yesno')->toOptionArray(),
                'after_element_html'    => '<td class="scope-label"><span class="nobr">' . Mage::helper('adminhtml')->__('[GLOBAL]') . '</span></td>',
            )
        );

        $_fieldset->addField(
            'priority',
            'text',
            array(
                'name'  => 'priority',
                'label' => $this->__('Sort Order'),
                'title' => $this->__('Sort Order'),
                'after_element_html'    => '<td class="scope-label"><span class="nobr">' . Mage::helper('adminhtml')->__('[GLOBAL]') . '</span></td>',
            )
        );

        $form->setValues($_data->getData());
        return parent::_prepareForm();
    }

    protected function _getAllWebsiteIds()
    {
        $websites = array();
        foreach (Mage::app()->getWebsites() as $website) {
            $websites[] = $website->getId();
        }
        return implode(',', $websites);
    }
}